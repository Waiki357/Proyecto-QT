#include "produccion.h"

Produccion::Produccion(string id):
    ID(id)
{}

Produccion::Produccion()
{}

Produccion::~Produccion(){
    PR.clear();
    ID.clear();
}

void Produccion::Set_Production(string P){
    PR.push_back(P);
}

void Produccion::Set_Production(vector<string> P){
    PR.clear();
    PR=P;
}

string Produccion::Get_Id(){
    return(ID);
}

vector<string> Produccion::Get_PR(){
    return(PR);
}

