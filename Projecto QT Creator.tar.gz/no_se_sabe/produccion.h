#ifndef PRODUCCION_H
#define PRODUCCION_H


#include <string>
#include <iostream>
#include <vector>

using namespace std;
class Produccion
{

    private:
        string ID;
        vector<string> PR;

    public:
        Produccion(string id);
        Produccion();
        ~Produccion();
        void Set_Production(string P);
        void Set_Production(vector<string> P);
        string Get_Id();
        vector<string> Get_PR();
};

#endif // PRODUCCION_H
