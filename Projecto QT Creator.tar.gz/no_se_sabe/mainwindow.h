#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QFont>
#include <QAction>
#include <QFontDialog>
#include <QFileDialog>
#include <QDebug>
#include <QTextDocument>
#include "cfg.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void alAbrir();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_5_clicked();

    void onEstructura();

private:
    Ui::MainWindow *ui;
    QStringList*    Original_;
    CFG*            CFG_;
    int             Contador;

};

#endif // MAINWINDOW_H
