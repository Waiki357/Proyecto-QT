#ifndef CFG_H
#define CFG_H

#include <iostream>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <set>
#include <stdlib.h>
#include <algorithm>
#include <QString>
#include <QStringList>
#include <QDebug>

#include "produccion.h"

using namespace std;

class CFG {

    private:
        set <string> Lenguaje_CFG;
        set <string> Symbol_N_T;
        vector <Produccion> P_;
        string Production_Start;
        int Num_Symbol_N_T;
        int Num_Symbol_T;

    public:
        CFG();
        ~CFG();
        void Set_CFG(QStringList *f);
        void set_CFG_Producciones(string linea,int Num_N_T);

        //Iniciar Numero Simbolos Terminales
        void Set_Num_Symbol_T(int S);

        //Iniciar Numero Simbolos No Terminales
        void Set_Num_Symbol_N_T(int S);

        //Iniciar Lenguaje
        void Set_Lenguaje_CFG(string L);

        //Iniciar Simbolos No Terminales
        void Set_Symbol_N_T(string S);

        int Get_Num_Symbol();
        int Get_Num_Symbol_N_T();
        string Get_Symbol();
        string Get_Symbol_N_T();
        vector<string> Get_Production();

        //Iniciar Las Producciones
        void set_CFG(string linea, int Num_N_T);

        //E.S Y P.I Etapa 1
        void Remove_Stage_1();

        //E.S Y P.I Etapa 2
        void Remove_Stage_2();

};

#endif // CFG_H
