#include "cfg.h"

CFG::CFG()
{}

CFG::~CFG()
{}

void CFG::Set_CFG(QStringList *f){

    //Terminales
    Set_Num_Symbol_T(f->at(0).toInt());
    string temp = f->at(1).toUtf8().constData();
    Set_Lenguaje_CFG(temp);

    //No Terminales
    Set_Num_Symbol_N_T(f->at(2).toInt());
    temp = f->at(3).toUtf8().constData();
    Set_Symbol_N_T(temp);

    //Producciones
    for (int k=0;k<Num_Symbol_N_T;k++){
        temp = f->at(4+k).toUtf8().constData();
        if (temp!=""){
           set_CFG_Producciones(temp,k);
        }

    }
}

void CFG::set_CFG_Producciones(string linea,int Num_N_T){
    size_t pos = 0;
    string token;
    string delimiter = " -> ";
    int cont=0;

    while ((pos = linea.find(delimiter)) != string::npos) {
        token = linea.substr(0, pos);

        if(cont==0){
            Produccion tmp(token);
            P_.push_back(tmp);
            cont++;
            linea.erase(0, pos + delimiter.length());
            delimiter=" | ";
        }

        else{
            P_[Num_N_T].Set_Production(token);
            linea.erase(0, pos + delimiter.length());
        }

    }
    P_[Num_N_T].Set_Production(linea);
}

void CFG::Set_Lenguaje_CFG(string L){

    size_t pos = 0;
    string token;
    string delimiter = " ";

    while ((pos = L.find(delimiter)) != string::npos) {
        token = L.substr(0, pos);
        Lenguaje_CFG.insert(token);
        L.erase(0, pos + delimiter.length());
    }
    Lenguaje_CFG.insert(L);
}

void CFG::Set_Symbol_N_T(string S){
    size_t pos = 0;
    string token;
    string delimiter = " ";

    while ((pos = S.find(delimiter)) != string::npos) {
        token = S.substr(0, pos);
        Symbol_N_T.insert(token);
        S.erase(0, pos + delimiter.length());
    }
    Symbol_N_T.insert(S);
}

void CFG::Set_Num_Symbol_T(int S){
    Num_Symbol_T=S;
}

void CFG::Set_Num_Symbol_N_T(int S){
    Num_Symbol_N_T=S;
}

int CFG::Get_Num_Symbol(){

    return(Num_Symbol_T);

}

int CFG::Get_Num_Symbol_N_T(){

    return(Num_Symbol_N_T);

}

string CFG::Get_Symbol(){
    string aux="";

    for (set<string>::iterator it=Lenguaje_CFG.begin(); it!=Lenguaje_CFG.end(); ++it){
        aux+=(*it);
        aux+=" ";

    }

    return(aux);

}

string CFG::Get_Symbol_N_T(){

    string aux="";

    for (set<string>::iterator it=Symbol_N_T.begin(); it!=Symbol_N_T.end(); ++it){
        aux+=(*it);
        aux+=" ";

    }
    return(aux);

}

vector<string> CFG::Get_Production(){

    vector<string> tmp;
    vector<string> aux;
    string aux2="";

    for(int i=0;i<Num_Symbol_N_T;i++){

        tmp = P_[i].Get_PR();
        aux2=P_[i].Get_Id();
        aux2+=" -> ";
        for(int j=0;j<tmp.size()-1;j++){
            aux2+=tmp[j];
            aux2+=" | ";
        }

        aux2+=tmp[tmp.size()-1];
        aux.push_back(aux2);
    }

    return(aux);
}



void CFG::Remove_Stage_1(){
    set <string> Conjunto,Conjunto1;
    bool M;
    string aux;
    vector<string> tmp;

    for(int i=0;i<Num_Symbol_N_T;i++){
        tmp=P_[i].Get_PR();
        for(int j=0;j<tmp.size();j++){
            M=false;
            aux=tmp[j];
            for (int it=0; it<tmp[j].size(); ++it){
                if(isupper(aux[it])){
                    M=true;
                }
            }
            if(!M){
                Conjunto.insert(P_[i].Get_Id());
            }
        }

    }

    while(Conjunto1!=Conjunto){

        string Aux1;
        Conjunto1=Conjunto;
        int Cont,Cont1;

        for(int i=0;i<Num_Symbol_N_T;i++){
            vector<string> tmp=P_[i].Get_PR();
            M=false;

            for(int j=0;j<tmp.size();j++){
                Aux1=tmp[j];
                Cont=0;
                Cont1=0;
                for(int p=0;p<Aux1.size();p++){
                    if(isupper(Aux1[p])){
                        Cont++;
                    }
                }
                for (set<string>::iterator it=Conjunto1.begin(); it!=Conjunto1.end(); ++it){
                    aux=(*it);
                    if((tmp[j].find(aux)) != string::npos)
                        Cont1++;
                }
                if(Cont==Cont1){
                    Conjunto.insert(P_[i].Get_Id());
                }
            }
        }
    }

    Conjunto1.clear();
    set_difference(Symbol_N_T.begin(), Symbol_N_T.end(), Conjunto.begin(), Conjunto.end(),inserter(Conjunto1, Conjunto1.begin()));

    int contador;
    for (set<string>::iterator it=Conjunto1.begin(); it!=Conjunto1.end(); ++it){
        aux=(*it);
        Symbol_N_T.erase(Symbol_N_T.find(aux));
        contador=Num_Symbol_N_T;
        for(int i=0;i<contador;i++){
            if(P_[i].Get_Id()==aux){
                P_.erase(P_.begin()+i);
                i=contador;
                Set_Num_Symbol_N_T(Num_Symbol_N_T-1);
            }
        }
    }

    for (set<string>::iterator it=Conjunto1.begin(); it!=Conjunto1.end(); ++it){
        aux=(*it);
        for(int i=0;i<Num_Symbol_N_T;i++){
            tmp=P_[i].Get_PR();
            contador=tmp.size();
            for(int j=0;j<contador;j++){
                if((tmp[j].find(aux)) != string::npos){
                    tmp.erase(tmp.begin()+j);
                    j=0;
                    contador=tmp.size();
                }
            }
            P_[i].Set_Production(tmp);
        }
    }
}

void CFG::Remove_Stage_2(){
    vector<string> J;
    set<string> E,V;

    J.push_back("S");
    V.insert("S");
    string aux,aux2,aux3;
    int cont;
    vector<string> tmp;

    while(J.size()!=0){
        aux3=J.back();
        J.pop_back();

        for(int r=0;r<Num_Symbol_N_T;r++){
            if(P_[r].Get_Id()==aux3)
                cont=r;
        }

        tmp=P_[cont].Get_PR();
        for (int j=0; j<tmp.size(); j++){
            aux=tmp[j];
            for (int i=0; i<aux.size(); i++){
                aux2=aux.substr (i,1);
                if(aux2!="~"){
                    if(!isupper(aux[i])){
                        E.insert(aux2);
                    }
                    else{

                        if((V.find(aux2)) == V.end()){
                            V.insert(aux2);
                            J.push_back(aux2);
                        }
                    }
                }
            }
        }
    }

    set<string> E_1,V_1;
    set_difference(Symbol_N_T.begin(), Symbol_N_T.end(), V.begin(), V.end(),inserter(V_1, V_1.begin()));
    set_difference(Lenguaje_CFG.begin(), Lenguaje_CFG.end(), E.begin(), E.end(),inserter(E_1, E_1.begin()));

    int contador;
    for (set<string>::iterator it=V_1.begin(); it!=V_1.end(); ++it){
        aux=(*it);
        Symbol_N_T.erase(Symbol_N_T.find(aux));
        contador=Num_Symbol_N_T;
        for(int i=0;i<contador;i++){
            if(P_[i].Get_Id()==aux){
                P_.erase(P_.begin()+i);
                i=contador;
                Set_Num_Symbol_N_T(Num_Symbol_N_T-1);
            }
        }
    }

    for (set<string>::iterator it=V_1.begin(); it!=V_1.end(); ++it){
        aux=(*it);
        for(int i=0;i<Num_Symbol_N_T;i++){
            tmp=P_[i].Get_PR();
            contador=tmp.size();
            for(int j=0;j<contador;j++){
                if((tmp[j].find(aux)) != string::npos){
                    tmp.erase(tmp.begin()+j);
                    j=0;
                    contador=tmp.size();
                }
            }
            P_[i].Set_Production(tmp);
        }
    }

    for (set<string>::iterator it=E_1.begin(); it!=E_1.end(); ++it){
        aux=(*it);
        Lenguaje_CFG.erase(Lenguaje_CFG.find(aux));
        for(int i=0;i<Num_Symbol_N_T;i++){
            tmp=P_[i].Get_PR();
            contador=tmp.size();
            for(int j=0;j<contador;j++){
                if((tmp[j].find(aux)) != string::npos){
                    tmp.erase(tmp.begin()+j);
                    j=0;
                    contador=tmp.size();
                }
            }
            P_[i].Set_Production(tmp);
        }
    }

    Set_Num_Symbol_T(Num_Symbol_T-E_1.size());
}
