#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    Contador(0),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->actionSalir,        SIGNAL(triggered()),     this,   SLOT(close()));
    connect(ui->actionAbrir_con,    SIGNAL(triggered()),     this,   SLOT(alAbrir()));

    ui->plainTextEdit_3->setReadOnly(true);
    ui->plainTextEdit_2->setReadOnly(true);
    ui->pushButton->setEnabled(false);
    ui->pushButton_2->setEnabled(false);
    ui->pushButton_3->setEnabled(false);
    ui->pushButton_4->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::alAbrir(){

    QString nombreArchivo;
    nombreArchivo = QFileDialog::getOpenFileName(this,
                                                 tr("Abrir archivo de texto plano"),
                                                 "",
                                                 tr("Archivos de texto plano (*.cfg)"));
    if (nombreArchivo != "") {
        QFile archivo;
        archivo.setFileName(nombreArchivo);
        if (archivo.open(QFile::ReadOnly)) {
            ui->plainTextEdit->setPlainText(archivo.readAll());
            archivo.close();
        }
    }
}

//Atrás
void MainWindow::on_pushButton_clicked()
{
    CFG CFG_Original;
    CFG_Original.Set_CFG(Original_);

    if(Contador==1){
        Contador--;

    }

    else{
        CFG_Original.Remove_Stage_1();
        Contador--;
    }

    ui->plainTextEdit_2->setPlainText(QString::number(CFG_Original.Get_Num_Symbol()));
    ui->plainTextEdit_2->appendPlainText(QString::fromStdString(CFG_Original.Get_Symbol()));
    ui->plainTextEdit_2->appendPlainText(QString::number((CFG_Original.Get_Num_Symbol_N_T())));
    ui->plainTextEdit_2->appendPlainText(QString::fromStdString(CFG_Original.Get_Symbol_N_T()));
    vector<string> tmp=CFG_Original.Get_Production();

    for(int i=0;i<tmp.size();i++){
        ui->plainTextEdit_2->appendPlainText(QString::fromStdString(tmp[i]));
    }

    ui->pushButton_2->setEnabled(true);
    if(Contador==0)
        ui->pushButton->setEnabled(false);

}

//Siguiente
void MainWindow::on_pushButton_2_clicked()
{

    CFG CFG_Original;
    CFG_Original.Set_CFG(Original_);

    if(Contador==0){
        CFG_Original.Remove_Stage_1();
        Contador++;

    }

    else{
        CFG_Original.Remove_Stage_1();
        CFG_Original.Remove_Stage_2();
        Contador++;
    }

    ui->plainTextEdit_2->setPlainText(QString::number(CFG_Original.Get_Num_Symbol()));
    ui->plainTextEdit_2->appendPlainText(QString::fromStdString(CFG_Original.Get_Symbol()));
    ui->plainTextEdit_2->appendPlainText(QString::number((CFG_Original.Get_Num_Symbol_N_T())));
    ui->plainTextEdit_2->appendPlainText(QString::fromStdString(CFG_Original.Get_Symbol_N_T()));
    vector<string> tmp=CFG_Original.Get_Production();

    for(int i=0;i<tmp.size();i++){
        ui->plainTextEdit_2->appendPlainText(QString::fromStdString(tmp[i]));
    }

    ui->pushButton->setEnabled(true);
    if(Contador==2)
        ui->pushButton_2->setEnabled(false);

}

//Final
void MainWindow::on_pushButton_3_clicked()
{
        ui->pushButton_4->setEnabled(true);
        ui->pushButton_3->setEnabled(false);
        ui->pushButton_2->setEnabled(false);
        ui->pushButton->setEnabled(false);
        CFG_->Remove_Stage_1();
        CFG_->Remove_Stage_2();
        ui->plainTextEdit_2->setPlainText(QString::number(CFG_->Get_Num_Symbol()));
        ui->plainTextEdit_2->appendPlainText(QString::fromStdString(CFG_->Get_Symbol()));
        ui->plainTextEdit_2->appendPlainText(QString::number((CFG_->Get_Num_Symbol_N_T())));
        ui->plainTextEdit_2->appendPlainText(QString::fromStdString(CFG_->Get_Symbol_N_T()));
        vector<string> tmp=CFG_->Get_Production();

        for(int i=0;i<tmp.size();i++){
            ui->plainTextEdit_2->appendPlainText(QString::fromStdString(tmp[i]));
        }

}

//Inicio
void MainWindow::on_pushButton_4_clicked()
{

    CFG CFG_Original;
    CFG_Original.Set_CFG(Original_);

    ui->pushButton_3->setEnabled(true);
    ui->pushButton_4->setEnabled(false);
    ui->pushButton_2->setEnabled(true);
    ui->plainTextEdit_2->setPlainText(QString::number(CFG_Original.Get_Num_Symbol()));
    ui->plainTextEdit_2->appendPlainText(QString::fromStdString(CFG_Original.Get_Symbol()));
    ui->plainTextEdit_2->appendPlainText(QString::number((CFG_Original.Get_Num_Symbol_N_T())));
    ui->plainTextEdit_2->appendPlainText(QString::fromStdString(CFG_Original.Get_Symbol_N_T()));
    vector<string> tmp=CFG_Original.Get_Production();

    for(int i=0;i<tmp.size();i++){
        ui->plainTextEdit_2->appendPlainText(QString::fromStdString(tmp[i]));
    }
}

void MainWindow::onEstructura(){
    Original_ = new QStringList;
    QString* plainTextEditContents;
    plainTextEditContents = new QString;

    *plainTextEditContents= ui->plainTextEdit->toPlainText();
    *Original_ = plainTextEditContents->split("\n");
}



void MainWindow::on_pushButton_5_clicked()
{
    onEstructura();
    CFG_ = new CFG;
    CFG_->Set_CFG(Original_);

    ui->pushButton_3->setEnabled(true);
    ui->pushButton_2->setEnabled(true);

}
